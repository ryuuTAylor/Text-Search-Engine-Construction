(* TODO: set the value below. *)
let hours_worked = 25
